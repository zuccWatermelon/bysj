<!--

IMPORTANT #1: Did the `vue init` command *itself* result in an error?

  -> NO: If the files for a project template were correctly created, but did
         not work out-of-the-box as you expected, please open an issue for the
         appropriate template at github.com/vuejs-templates

  -> YES: Open an issue here. Please include the exact command you used,
          what you expected to happen, and what happened instead.

IMPORTANT #2: Please use English language so we can help you faster.
-->
