module.exports = {
  prompts: {
    name: {
      type: 'string',
      required: true,
      message: 'Name'
    }
  }
}
