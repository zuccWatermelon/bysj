Metalsmith {{after}} and {{before}} hooks
