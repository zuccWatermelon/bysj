<template>
  \{{yes}} {{pick}}
</template>
