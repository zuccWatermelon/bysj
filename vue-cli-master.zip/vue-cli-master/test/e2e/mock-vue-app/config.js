module.exports = {
  autoprefixer: {
    browsers: ['ie > 10']
  }
}
