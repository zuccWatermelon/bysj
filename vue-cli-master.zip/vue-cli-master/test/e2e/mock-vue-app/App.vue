<template>
  <h2>hello</h2>
</template>

<style>
  body {
    display: flex;
  }
</style>
